/* Automation Studio generated header file */
/* Do not edit ! */
/* snprintf 1.10.2 */

#ifndef _SNPRINTF_
#define _SNPRINTF_
#ifdef __cplusplus
extern "C" 
{
#endif
#ifndef _snprintf_VERSION
#define _snprintf_VERSION 1.10.2
#endif

#include <bur/plctypes.h>

#ifndef _BUR_PUBLIC
#define _BUR_PUBLIC
#endif



/* Prototyping of functions and function blocks */
_BUR_PUBLIC signed char snprintf2(char *s, int size, char *fmt, ...);


#ifdef __cplusplus
};
#endif
#endif /* _SNPRINTF_ */

